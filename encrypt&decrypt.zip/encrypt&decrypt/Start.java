class Start
{
	Start()
	{
		new CryptoGUI();
	}
	public static void main(String[] args) {
		new Start();
	}
}